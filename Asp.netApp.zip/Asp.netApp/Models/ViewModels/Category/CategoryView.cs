﻿namespace Asp.netApp.Models.ViewModels.Category
{
    public class CategoryView
    {
        public int Id;
        public string CategoryName;
        public int Count;
    }
}
