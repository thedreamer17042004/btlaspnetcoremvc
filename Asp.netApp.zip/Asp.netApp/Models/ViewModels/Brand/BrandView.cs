﻿namespace Asp.netApp.Models.ViewModels.Product
{
    public class BrandView
    {
        public int BrandId;
        public string BrandName;
        public int Count;
    }
}
