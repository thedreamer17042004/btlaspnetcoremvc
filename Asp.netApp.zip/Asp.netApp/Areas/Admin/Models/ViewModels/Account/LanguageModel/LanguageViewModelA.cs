﻿namespace Asp.netApp.Areas.Admin.Models.ViewModels.Account.LanguageModel
{
    public class LanguageViewModelA : ILanguageViewModel
    {
        public string Parent { get; set; }
        public string Child { get; set; }
        public string SecondChild { get; set; }
    }
}
