﻿namespace Asp.netApp.Areas.Admin.Constants
{
    public class UserRole
    {
        public static string ADMIN = "ADMIN";
        public static string USER = "USER";
        public static string MANAGER = "MANAGER";
        public static string STAFF = "STAFF";  
    }
}
