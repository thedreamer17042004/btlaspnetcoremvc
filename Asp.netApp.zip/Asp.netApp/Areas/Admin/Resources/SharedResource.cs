﻿namespace Asp.netApp.Areas.Admin.Resources
{
    public class SharedResource
    {
    }
}
